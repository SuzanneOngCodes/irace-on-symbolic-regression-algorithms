spartialEvoFunc = str2sym('1/(1+x1^-4) + 1/(1+x2^-4)');
h = ezsurf(spartialEvoFunc,(-5:5),150);
h.LineStyle = 'none';
light;
colormap summer; 
material shiny;
h.FaceAlpha = 0.5;

% st.exe
% txt file 
% justify -> csv: Find limitations
% Random
% Parameter settings
% Memory, Time, Size 
% Visualisation not a priority -> Heatmap 
% Proof of concept -> make sure -> aim for some prototype
% Record your presentation -> tangible 
% Importance of your presentation
% Structured notebook